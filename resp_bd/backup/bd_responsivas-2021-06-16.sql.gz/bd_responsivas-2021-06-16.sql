-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: bd_responsivas
-- ------------------------------------------------------
-- Server version	10.3.27-MariaDB-0+deb10u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_Almacen`
--

DROP TABLE IF EXISTS `t_Almacen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Almacen` (
  `id_almacen` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  PRIMARY KEY (`id_almacen`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Almacen`
--

LOCK TABLES `t_Almacen` WRITE;
/*!40000 ALTER TABLE `t_Almacen` DISABLE KEYS */;
INSERT INTO `t_Almacen` VALUES (1,'PLANTA 3 - ALMACEN'),(2,'Planta 3 - IDF1'),(3,'PLANTA 3 IDF2');
/*!40000 ALTER TABLE `t_Almacen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Centro_Costos`
--

DROP TABLE IF EXISTS `t_Centro_Costos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Centro_Costos` (
  `id_centro_costos` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `num_centro_costos` varchar(30) NOT NULL,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`id_centro_costos`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Centro_Costos`
--

LOCK TABLES `t_Centro_Costos` WRITE;
/*!40000 ALTER TABLE `t_Centro_Costos` DISABLE KEYS */;
INSERT INTO `t_Centro_Costos` VALUES (1,'17300426','IT'),(2,'17311216','ADUANAS'),(3,'17311217','WAREHOUSE INVENTORY CONTROL'),(4,'17313232','MANUFACTURING'),(5,'17311232','OPERATIONS'),(6,'17313240','PROGRAM MANAGEMENT'),(7,'17313248','QA REGULATORY'),(8,'17313245','MANUFACTURING'),(9,'17300416','RECRUITING'),(10,'17313290','MANUFACTURING'),(11,'17313233','Industrial Engineering');
/*!40000 ALTER TABLE `t_Centro_Costos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Cintas`
--

DROP TABLE IF EXISTS `t_Cintas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Cintas` (
  `id_cintas` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `num_serial` varchar(15) NOT NULL,
  `fecha_inic` date DEFAULT NULL,
  `fecha_final` date DEFAULT NULL,
  `ubicacion` varchar(20) NOT NULL,
  `comentarios` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_cintas`)
) ENGINE=InnoDB AUTO_INCREMENT=274 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Cintas`
--

LOCK TABLES `t_Cintas` WRITE;
/*!40000 ALTER TABLE `t_Cintas` DISABLE KEYS */;
INSERT INTO `t_Cintas` VALUES (1,'FSU539L5','2021-05-01','1970-01-01','X03,Y01,Z01','1261,10 YEARS,TIJ-EOM,1       <===> Fecha Incompleta '),(2,'FSU550L5','2021-04-03','1970-01-01','X03,Y01,Z01','5FA6, 10 YEARS,TIJ-EOM, FSU550L5, 1       <===> Fecha Incompleta '),(3,'FSU529L5','2021-03-06','1970-01-01','X03,Y01,Z01','597C, 10 YEARS,TIJ-EOM, FSU529L5, 1       <===> Fecha Incompleta '),(4,'FSU524L5','2021-02-06','2021-02-06','X03,Y01,Z01','79DB, 10 YEARS,12:04 AM, FSU524L5, 1'),(5,'FSU464L5','2021-01-02','2021-01-07','X03,Y01,Z01','48F8, 10 YEARS, FSU464L5, 1'),(6,'FRI481L5','2020-05-02','1970-01-01','X3,Y1,Z1 ','9731, 10 YEARS, TIJ_EOM, 2       <===> Fecha Incompleta '),(7,'FRI483L5','2020-12-10','1970-01-01','X3,Y1,Z1 ','       <===> Fecha Incompleta 44175'),(8,'FRI493L5','2020-07-05','1970-01-01','X3,Y1,Z1 ','E41E,  10 YEARS, TIJ_EOM, 1       <===> Fecha Incompleta '),(9,'FRI499L5','2020-01-05','1970-01-01','X3,Y1,Z1 ','793D, 10 YEARS, TIJ-EOM, 2       <===> Fecha Incompleta '),(10,'FSU467L5','2020-11-07','2020-11-07','X3,Y1,Z1 ','7E37, 10 YEAR, 1'),(11,'FSU468L5','1970-01-01','1970-01-01','X2,Y1,Z1 ','EOM AUGUST       <===> Fecha Incompleta 08/01/'),(12,'FSU472L5','2020-11-07','2020-11-07','X2,Y1,Z1 ','7E37, 10 YEARS, 12:04 AM, 2'),(13,'FSU475L5','2020-04-01','1970-01-01','X2,Y1,Z1 ','EOM APRIL       <===> Fecha Incompleta '),(14,'FSU486L5','2020-01-04','1970-01-01','X2,Y1,Z1 ','793D, 10 YEARS, TIJ_EOM, 1       <===> Fecha Incompleta '),(15,'FSU493L5','1970-01-01','1970-01-01','X2,Y1,Z1 ','EOM APRIL       <===> Fecha Incompleta 4/1/'),(16,'PI1606L5','2020-04-05','1970-01-01','X2,Y1,Z1 ','10 YEARS, TIJ-EOM, 1       <===> Fecha Incompleta '),(17,'PI1607L5','2020-12-05','2020-12-05','X2,Y1,Z1 ','449E, 10 YEARS,1'),(18,'PI1608L5','2020-06-08','1970-01-01','X2,Y1,Z1 ','80EC, 10 YEARS, 1       <===> Fecha Incompleta '),(19,'PI1614L5','2020-12-05','2020-12-05','X2,Y1,Z1 ','449E, 10 YEARS,2'),(20,'PI1616L5','2020-02-22','1970-01-01','X2,Y1,Z1 ','16D7, TIJ-1-FULL, 31 DAYS, 2       <===> Fecha Incompleta '),(21,'PI1661L5','2020-02-22','1970-01-01','X1,Y1,Z1 ','16D7, TIJ-1-FULL, 31 DAYS, 1       <===> Fecha Incompleta '),(22,'PI1662L5','2020-06-06','1970-01-01','X1,Y1,Z1 ','3288, 10 YEARS, TIJ-EOM,1       <===> Fecha Incompleta '),(23,'PI1663L5','2020-03-07','1970-01-01','X1,Y1,Z1 ','C9FF, TIJ-EOM, 1       <===> Fecha Incompleta '),(24,'PI1667L5','2020-10-03','2020-10-03','X1,Y1,Z1 ','626f, 10 YEARS, 12:07 AM, 2'),(25,'PI1671L5','2020-02-01','1970-01-01','X1,Y1,Z1 ','7224, 10 YEARS, TIJ_EOM, 1       <===> Fecha Incompleta '),(26,'PI1672L5','2020-08-01','2020-08-01','X1,Y1,Z1 ','4245, 10 YEARS, 1'),(27,'PI1673L5','2020-06-06','1970-01-01','X1,Y1,Z1 ','3288, 10 YEARS, TIJ-EOM, 2       <===> Fecha Incompleta '),(28,'PI1676L5','2020-10-03','2020-10-03','X1,Y1,Z1 ','626F, 10 YEAR, 1'),(29,'PI1678L5','2020-02-02','1970-01-01','X1,Y1,Z1 ','7224, 10 YEARS, TIJ-EOM, 2       <===> Fecha Incompleta '),(30,'PI1679L5','2020-09-05','2020-09-05','X1,Y1,Z1 ','59B8, 10 YEARS, 12:04 AM, 2'),(31,'TIJ00CL5','2020-09-05','2020-09-05','X4,Y3,Z2 ','59B8, 10 YEARS, 12:04 AM, 1'),(32,'TIJ014L5','2020-02-21','1970-01-01','X4,Y3,Z2 ','8400, 31 DAYS, TIJ_1_INCR, 1       <===> Fecha Incompleta '),(33,'TIJ038L5','2020-07-04','1970-01-01','X4,Y3,Z2 ','4DA2, 10 YEARS, TIJ_EOM, 2       <===> Fecha Incompleta '),(34,'TIJ058L5','2020-07-04','1970-01-01','X4,Y3,Z2 ','4DA2, 10 YEAR,1       <===> Fecha Incompleta '),(35,'TIJ06CL5','2020-02-24','1970-01-01','X4,Y3,Z2 ','6DCB, 31 DAYS, 1       <===> Fecha Incompleta '),(36,'TIJ076L5','2020-04-06','1970-01-01','X4,Y3,Z2 ','3902, TIJ-EOM, 10 YEARS, 2       <===> Fecha Incompleta '),(37,'TIJ0B6L5','2020-05-02','1970-01-01','X4,Y3,Z2 ','9731, 10 YERS, TIJ-EOM, 1       <===> Fecha Incompleta '),(38,'FRI480L5','2019-09-15','1970-01-01','X4,Y3,Z2 ','8E48, OEM, 6       <===> Fecha Incompleta '),(39,'FRI482L5','2019-07-08','1970-01-01','X4,Y3,Z2 ','B518, 10 YEARS, TIJ-EOM, 6       <===> Fecha Incompleta '),(40,'FRI484L5','2019-09-15','1970-01-01','X4,Y3,Z2 ','8E48, TIJ, EOM, 5       <===> Fecha Incompleta '),(41,'FRI485L5','2019-08-04','1970-01-01','X3,Y3,Z2 ','729D, 10 YEARS, TIJ-EOM, 4       <===> Fecha Incompleta '),(42,'FRI486L5','2019-08-04','1970-01-01','X3,Y3,Z2 ','729D, 10 YEARS, TIJ-EOM, 5       <===> Fecha Incompleta '),(43,'FRI487L5','2019-07-08','1970-01-01','X3,Y3,Z2 ','B518, 10 YEARS, TIJ_EOM, 4       <===> Fecha Incompleta '),(44,'FRI488L5','2019-10-07','1970-01-01','X3,Y3,Z2 ','910E, 10 YEARS, TIJ-EOM, 3       <===> Fecha Incompleta '),(45,'FRI489L5','2019-07-08','1970-01-01','X3,Y3,Z2 ','B518, 10 YEARS, TIJ_EOM, 3       <===> Fecha Incompleta '),(46,'FRI490L5','2019-07-16','1970-01-01','X3,Y3,Z2 ','B518, 10 YEARS, TIJ_EOM, 1       <===> Fecha Incompleta '),(47,'FRI492L5','2019-12-07','1970-01-01','X3,Y3,Z2 ','866F, 10 YEAR, 1       <===> Fecha Incompleta '),(48,'FRI494L5','2019-07-08','1970-01-01','X3,Y3,Z2 ','B518, 10 YERS, TIJ-EOM, 5       <===> Fecha Incompleta '),(49,'FRI495L5','2019-12-08','1970-01-01','X3,Y3,Z2 ','866F, 10 YEARS, TIJ-EOM, 3       <===> Fecha Incompleta '),(50,'FRI496L5','2019-08-04','1970-01-01','X3,Y3,Z2 ','729D, 10 YEARS, 6       <===> Fecha Incompleta '),(51,'FRI497L5','2019-10-16','1970-01-01','X2,Y3,Z2 ','A9BF, 31 DAYS, 7       <===> Fecha Incompleta '),(52,'FRI498L5','2019-10-07','1970-01-01','X2,Y3,Z2 ','910E, 10 YEARS, TIJ_EOM, 9       <===> Fecha Incompleta '),(53,'FSU466L5','2019-08-04','1970-01-01','X2,Y3,Z2 ','729D, 10 YEARS, 3       <===> Fecha Incompleta '),(54,'FSU469L5','2019-10-07','1970-01-01','X2,Y3,Z2 ','910E, 10 YEARS, TIJ_EOM, 6       <===> Fecha Incompleta '),(55,'FSU470L5','2019-04-07','1970-01-01','X2,Y3,Z2 ','7652, 3, ETIQUETA CORTADA       <===> Fecha Incompleta '),(56,'FSU474L5','2019-07-08','1970-01-01','X2,Y3,Z2 ','B518, 10 YEARS, TIJ-EOM, 2       <===> Fecha Incompleta '),(57,'FSU477L5','2019-10-06','1970-01-01','X2,Y3,Z2 ','910E, 10 YEARS, TIJ_EOM, 2       <===> Fecha Incompleta '),(58,'FSU480L5','2019-06-03','1970-01-01','X2,Y3,Z2 ','ADAA, 10 YEARS, 6       <===> Fecha Incompleta '),(59,'FSU481L5','2019-06-01','1970-01-01','X2,Y3,Z2 ','ADAA, 10 YEARS, 1       <===> Fecha Incompleta '),(60,'FSU482L5','2019-04-09','1970-01-01','X2,Y3,Z2 ','7652, 10 YEARS, TIJ_EOM, 4       <===> Fecha Incompleta '),(61,'FSU484L5','2019-10-07','1970-01-01','X1,Y3,Z2','910E, 10 YEARS, 5       <===> Fecha Incompleta '),(62,'FSU485L5','2019-04-09','1970-01-01','X1,Y3,Z2','7652, 10 YEARS, TIJ_EOM, 5       <===> Fecha Incompleta '),(63,'FSU490L5','2019-08-03','1970-01-01','X1,Y3,Z2','729D, 10 YEARS, TIJ-EOM, 1       <===> Fecha Incompleta '),(64,'FSU511L5','2019-05-01','1970-01-01','X1,Y3,Z2','OFM       <===> Fecha Incompleta '),(65,'PI1601L5','2019-09-15','1970-01-01','X1,Y3,Z2','8E48, TIJ_OEM, 3       <===> Fecha Incompleta '),(66,'PI1602L5','2019-11-12','1970-01-01','X1,Y3,Z2','AB22, TIJ_EOM, 4       <===> Fecha Incompleta '),(67,'PI1603L5','2019-11-12','1970-01-01','X1,Y3,Z2','AB22, 10 YEARS, TIJ-EOM, 2       <===> Fecha Incompleta '),(68,'PI1609L5','2019-11-12','1970-01-01','X1,Y3,Z2','AB22, 10 YEARS, TIJ-EOM, 6       <===> Fecha Incompleta '),(69,'PI1611L5','2019-11-12','1970-01-01','X1,Y3,Z2','AB22, 10 YEARS, 2       <===> Fecha Incompleta '),(70,'PI1619L5','2019-11-12','1970-01-01','X1,Y3,Z2','AB22, 10 YEARS, TIJ-EOM, 1       <===> Fecha Incompleta '),(71,'TIJ003L5','2019-05-06','1970-01-01','X4,Y2,Z2','CF31, 10 YEARS, TIJ_EOM, 4       <===> Fecha Incompleta '),(72,'TIJ005L5','2019-10-07','1970-01-01','X4,Y2,Z2','866F, 10 YEARS, TIJ_EOM, 2       <===> Fecha Incompleta '),(73,'TIJ006L5','2019-01-06','1970-01-01','X4,Y2,Z2','2D3B, 10 YEARS, TIJ_1_FULL, 5       <===> Fecha Incompleta '),(74,'TIJ00EL5','2019-02-02','2019-02-04','X4,Y2,Z2','7D78, 10 YEARS, 4'),(75,'TIJ015L5','2019-12-08','1970-01-01','X4,Y2,Z2','866F, 10 YEAR, 4       <===> Fecha Incompleta '),(76,'TIJ017L5','2019-04-06','1970-01-01','X4,Y2,Z2','7652, 10 YEARS, TIJ-EOM, 2       <===> Fecha Incompleta '),(77,'TIJ023L5','2019-01-06','1970-01-01','X4,Y2,Z2','2D3B, 10 YEARS, TIJ_1_FULL, 3       <===> Fecha Incompleta '),(78,'TIJ031L5','2019-02-02','2019-02-04','X4,Y2,Z2','7D78, 10 YEARS, 6'),(79,'TIJ036L5','2019-02-02','2019-02-02','X4,Y2,Z2','7178, 10 YEAR, 1'),(80,'TIJ039L5','2019-06-03','1970-01-01','X4,Y2,Z2','ADAA, 10 YEARS, TIJ-EOM, 5       <===> Fecha Incompleta '),(81,'TIJ03BL5','2019-08-04','1970-01-01','X3,Y2,Z2','729D, 10 YEARS, TIJ-EOM, 2       <===> Fecha Incompleta '),(82,'TIJ03CL5','2019-11-12','1970-01-01','X3,Y2,Z2','ABZZ, 10 YEARS, TIJ_EOM, 3       <===> Fecha Incompleta '),(83,'TIJ040L5','2019-12-08','1970-01-01','X3,Y2,Z2','866F, 10 YEARS, TIJ_EOM, 5       <===> Fecha Incompleta '),(84,'TIJ046L5','2019-03-05','1970-01-01','X3,Y2,Z2','7D61, 10 YEARS, TIJ_1_FULL       <===> Fecha Incompleta '),(85,'TIJ04BL5','2019-02-02','2019-02-04','X3,Y2,Z2','7D78, 10 YEARS, 3'),(86,'TIJ04CL5','2019-03-05','1970-01-01','X3,Y2,Z2','7D61, 10 YEARS, TIJ_1_FULL       <===> Fecha Incompleta '),(87,'TIJ052L5','2019-01-06','1970-01-01','X3,Y2,Z2','2D3B, 10 YEARS, TIJ_1_FULL, 6       <===> Fecha Incompleta '),(88,'TIJ05FL5','2019-06-03','1970-01-01','X3,Y2,Z2','ADAA, 10 YEARS, TIJ_EOM, 3       <===> Fecha Incompleta '),(89,'TIJ061L5','2019-03-05','1970-01-01','X3,Y2,Z2','7D61, 10 YEARS, TIJ_1_FULL,       <===> Fecha Incompleta '),(90,'TIJ063L5','2019-09-15','1970-01-01','X3,Y2,Z2','8E48, TIJ_E0M, 1       <===> Fecha Incompleta '),(91,'TIJ064L5','2019-01-05','1970-01-01','X2,Y2,Z2','2D3B, 10 YEARS, TIJ_1_FULL, 1       <===> Fecha Incompleta '),(92,'TIJ065L5','2019-01-06','1970-01-01','X2,Y2,Z2','2D3B, 10 YEARS, TIJ_1_FULL, 2       <===> Fecha Incompleta '),(93,'TIJ068L5','2019-09-15','1970-01-01','X2,Y2,Z2','8E48, TIJ, EOM, 4       <===> Fecha Incompleta '),(94,'TIJ06EL5','2019-03-05','2019-03-05','X2,Y2,Z2','5D72, 10 YEARS, 1'),(95,'TIJ070L5','2019-02-02','2019-02-04','X2,Y2,Z2','7D78, 10 YEARS, 5'),(96,'TIJ072L5','2019-03-12','1970-01-01','X2,Y2,Z2','7D61, 10 YEARS, TIJ_1_FULL,2       <===> Fecha Incompleta '),(97,'TIJ079L5','2019-10-07','1970-01-01','X2,Y2,Z2','910E, TIJ-EOM,7       <===> Fecha Incompleta '),(98,'TIJ081L5','2019-03-05','1970-01-01','X2,Y2,Z2','7D61, 10 YEARS, TIJ_1_FULL       <===> Fecha Incompleta '),(99,'TIJ082L5','2019-06-03','1970-01-01','X2,Y2,Z2','ADAA, 10 YEARS, TIJ_EOM, 4       <===> Fecha Incompleta '),(100,'TIJ084L5','2019-05-04','1970-01-01','X1,Y2,Z2','CF31, 10 YEARS, TIJ-EOM, 1       <===> Fecha Incompleta '),(101,'TIJ086L5','2019-10-11','1970-01-01','X1,Y2,Z2','BE6C, 31 DAYS, 1       <===> Fecha Incompleta '),(102,'TIJ088L5','2019-03-05','1970-01-01','X1,Y2,Z2','7D61, 10 YEARS, TIJ_1_FULL       <===> Fecha Incompleta '),(103,'TIJ08BL5','2019-05-06','1970-01-01','X1,Y2,Z2','CF31, 10 YEARS, TIJ_EOM, 2       <===> Fecha Incompleta '),(104,'TIJ096L5','2019-10-05','1970-01-01','X1,Y2,Z2','910E, 10 YEARS, TIJ-EOM, 1       <===> Fecha Incompleta '),(105,'TIJ099L5','2019-06-03','1970-01-01','X1,Y2,Z2','ADAA, 10 YEARS, TIJ-EOM, 2       <===> Fecha Incompleta '),(106,'TIJ09AL5','2019-01-06','1970-01-01','X1,Y2,Z2','2D3B, 10 YEARS, TIJ_1_FULL, 4       <===> Fecha Incompleta '),(107,'TIJ09BL5','2019-03-05','1970-01-01','X1,Y2,Z2','7D61, 10 YEARS, TIJ-1-FULL, ?       <===> Fecha Incompleta '),(108,'TIJ09EL5','2019-06-03','1970-01-01','X1,Y2,Z2','ADAA, 10 YEARS, TIJ_EOM, 7       <===> Fecha Incompleta '),(109,'TIJ09FL5','2019-05-06','1970-01-01','X1,Y2,Z2','CF31-777, TIJ-OEM, 10 YEARS       <===> Fecha Incompleta '),(110,'TIJ0A0L5','2019-04-09','1970-01-01','X4,Y1,Z2','7652, 10 YEARS, TIJ-EOM, 7       <===> Fecha Incompleta '),(111,'TIJ0A4L5','2019-05-06','1970-01-01','X4,Y1,Z2','CF31, 10 YEARS, TIJ-EOM, 6       <===> Fecha Incompleta '),(112,'TIJ0ADL5','2019-05-06','1970-01-01','X4,Y1,Z2','CF31, 10 YEARS, TIJ-EOM, 3       <===> Fecha Incompleta '),(113,'TIJ0B1L5','2019-04-09','1970-01-01','X4,Y1,Z2','7652, 10 YEARS, TIJ_EOM, 6       <===> Fecha Incompleta '),(114,'TIJ0BBL5','2019-09-15','1970-01-01','X4,Y1,Z2','8E48, TIJ_OEM, 2       <===> Fecha Incompleta '),(115,'TIJ0C3L5','2019-02-02','2019-02-04','X4,Y1,Z2','7D78, 10 YEARS, 2'),(116,'TIJ000L5','2018-06-02','2018-06-02','X4,Y1,Z2','97AD, 10 YEARS, 1'),(117,'TIJ004L5','2018-03-03','2018-03-08','X4,Y1,Z2','A271, 10 YERAS, 1'),(118,'TIJ009L5','2018-02-03','2018-02-05','X4,Y1,Z2','CCB6, 10 YEARS, 2'),(119,'TIJ00DL5','2018-02-13','2018-02-05','X4,Y1,Z2','CCB6, 10 YEARS, 4'),(120,'TIJ00FL5','2018-03-03','2018-03-04','X3,Y1,Z2','A271, 10 YERAS, 3'),(121,'TIJ013L5','2018-03-03','2018-03-04','X3,Y1,Z2','A271, 10 YEAR, 5'),(122,'TIJ016L5','2018-06-02','2018-06-03','X3,Y1,Z2','97AD, 10 YEARS. 2'),(123,'TIJ01AL5','2018-05-05','2018-05-06','X3,Y1,Z2','A646, 10 YEARS, 4'),(124,'TIJ01BL5','2018-01-09','1970-01-01','X3,Y1,Z2','1644, 10 YEARS, 3       <===> Fecha Incompleta '),(125,'TIJ01DL5','2018-10-06','2018-10-09','X3,Y1,Z2','CBB9, 10 YEARS, 4'),(126,'TIJ01FL5','2018-02-06','2018-02-06','X3,Y1,Z2','AD95, 10 YEARS, 1'),(127,'TIJ025L5','2018-02-03','2018-02-05','X3,Y1,Z2','CCB6, 10 YEARS, 3'),(128,'TIJ026L5','2018-03-03','2018-03-04','X3,Y1,Z2','A271, 10 YEAR, 4'),(129,'TIJ028L5','2018-11-03','2018-11-05','X3,Y1,Z2','8AF9, 10 YEARS, 2'),(130,'TIJ029L5','2018-09-02','2018-09-04','X2,Y1,Z2','5123, 10 YEARS, 6'),(131,'TIJ02AL5','2018-04-07','2018-04-08','X2,Y1,Z2','A769, 10 YEARS, 3'),(132,'TIJ02CL5','2018-05-05','2018-05-06','X2,Y1,Z2','A646, 10 YEARS, 2'),(133,'TIJ02DL5','2018-10-06','2018-10-04','X2,Y1,Z2','CBB9, 10 YEARS, 5'),(134,'TIJ02EL5','2018-06-03','2018-06-03','X2,Y1,Z2','97AD, 10 YEARS, 4'),(135,'TIJ033L5','2018-09-02','2018-09-04','X2,Y1,Z2','5123, 10 YEARS, 2'),(136,'TIJ034L5','2018-08-06','2018-08-13','X2,Y1,Z2','98FE, 10 YEARS, 1'),(137,'TIJ037L5','2018-05-05','2018-05-06','X2,Y1,Z2','A646, 10 YEAR , 5'),(138,'TIJ03AL5','2018-10-06','2018-10-06','X2,Y1,Z2','CBB9, 10 YEARS, 1'),(139,'TIJ03DL5','2018-02-03','2018-02-03','X2,Y1,Z2','CCB6, 10 YEARS, 1'),(140,'TIJ03EL5','2018-07-07','2018-07-07','X1,Y1,Z2','C501, 10 YEARS, 1'),(141,'TIJ03FL5','2018-09-02','2018-09-02','X1,Y1,Z2','5123, 10 YEARS, 1'),(142,'TIJ041L5','2018-08-08','2018-08-13','X1,Y1,Z2','928C, 10 YEARS, 2'),(143,'TIJ043L5','2018-07-07','1970-01-01','X1,Y1,Z2','C501, 10 YEARS, 5       <===> Fecha Incompleta '),(144,'TIJ04AL5','2018-07-08','2018-07-08','X1,Y1,Z2','C501, 10 YEARS, 4'),(145,'TIJ04FL5','2018-07-07','2018-07-08','X1,Y1,Z2','C501, 10 YEARS, 2'),(146,'TIJ050L5','2018-01-09','2018-01-11','X1,Y1,Z2','1644, 10 YEARS, 5'),(147,'TIJ051L5','2018-12-01','2018-12-03','X1,Y1,Z2','A1EB, 10 YEARS, 2'),(148,'TIJ057L5','2018-08-08','2018-08-13','X1,Y1,Z2','928C, 10 YEARS, 1'),(149,'TIJ059L5','2018-04-07','2018-04-08','X1,Y1,Z2','A769, 10 YEARS, 5'),(150,'TIJ05AL5','2018-01-09','2018-01-10','X4,Y3,Z3','1644, 10 YEARS,2'),(151,'TIJ05BL5','2018-01-09','1970-01-01','X4,Y3,Z3','1644, 10 YEARS, 4'),(152,'TIJ05DL5','2018-09-02','2018-09-04','X4,Y3,Z3','5123, 10 YEARS, 3'),(153,'TIJ05EL5','2018-08-13','1970-01-01','X4,Y3,Z3','982F, 10 YEARS, TIJ_1_INCR, 2       <===> Fecha Incompleta '),(154,'TIJ062L5','2018-08-13','1970-01-01','X4,Y3,Z3','982F, 10 YEARS, TIJ_1_INCR, 4       <===> Fecha Incompleta '),(155,'TIJ071L5','2018-05-05','2018-05-06','X4,Y3,Z3','A646, 10 YEARS, 3'),(156,'TIJ073L5','2018-08-13','1970-01-01','X4,Y3,Z3','982F, 10 YEARS, TIJ_1_NCR, 3       <===> Fecha Incompleta '),(157,'TIJ074L5','2018-08-06','2018-08-13','X4,Y3,Z3','98FE, 10 YEARS, 2'),(158,'TIJ078L5','2018-11-03','2018-11-05','X4,Y3,Z3','8AF9, 10 YEARS, 4'),(159,'TIJ07AL5','2018-01-09','2018-01-09','X4,Y3,Z3','1644, 10 YEAR. 1'),(160,'TIJ07DL5','2018-05-05','2018-05-05','X3,Y3,Z3','A646, 10  YEAR, 1'),(161,'TIJ080L5','2018-12-01','2018-12-03','X3,Y3,Z3','A1EB, 10 YEARS, 6'),(162,'TIJ083L5','2018-11-03','2018-11-05','X3,Y3,Z3','8AF9, 10 YEARS, 5'),(163,'TIJ087L5','2018-11-03','2018-11-06','X3,Y3,Z3','8AF9, 10 YEARS, 6'),(164,'TIJ089L5','2018-12-01','2018-12-03','X3,Y3,Z3','A1EB, 10 YEARS, 3'),(165,'TIJ08AL5','2018-12-01','2018-12-03','X3,Y3,Z3','A1EB, 10 YEARS, 4'),(166,'TIJ08DL5','2018-08-08','2018-08-13','X3,Y3,Z3','928C, 10 YEARS, 4'),(167,'TIJ090L5','2018-11-03','2018-11-03','X3,Y3,Z3','8AF9, 10 YEARS, 1'),(168,'TIJ091L5','2018-04-07','2018-04-08','X3,Y3,Z3','A769, 10 YEARS, 4'),(169,'TIJ092L5','2018-08-08','2018-08-13','X3,Y3,Z3','928C, 10 YEARS, 5'),(170,'TIJ094L5','2018-09-02','2018-09-04','X2,Y3,Z3','5123, 10 YEARS, 4'),(171,'TIJ09CL5','2018-08-13','1970-01-01','X2,Y3,Z3','982F, 10 YEARS, TIJ_1_INCR, 1       <===> Fecha Incompleta '),(172,'TIJ0A2L5','2018-04-07','2018-04-07','X2,Y3,Z3','A769, 10 YEARS, 1'),(173,'TIJ0A5L5','2018-07-08','2018-07-08','X2,Y3,Z3','C501, 10 YEARS, 3'),(174,'TIJ0A6L5','2018-08-13','1970-01-01','X2,Y3,Z3','982F, 10 YEARS, TIJ_1_INCR, 5       <===> Fecha Incompleta '),(175,'TIJ0A7L5','2018-10-06','2018-10-10','X2,Y3,Z3','CBB9, 10 YEARS, 6'),(176,'TIJ0AEL5','2018-03-03','2018-03-04','X2,Y3,Z3','A271, 10 YEAR, 2'),(177,'TIJ0AFL5','2018-05-07','2018-05-07','X2,Y3,Z3','5B90, 10 YEAR, 1'),(178,'TIJ0B4L5','2018-04-07','2018-04-08','X2,Y3,Z3','A769, 10 YEARS, 2'),(179,'TIJ0B5L5','2018-11-03','2018-11-05','X2,Y3,Z3','8AF9, 10 YEARS, 3'),(180,'TIJ0B7L5','2018-09-02','2018-09-04','X1,Y3,Z3','5123, 10 YEARS, 5'),(181,'TIJ0BCL5','2018-10-06','2018-10-09','X1,Y3,Z3','CBB9, 10 YEARS, 2'),(182,'TIJ0BDL5','2018-06-02','2018-06-03','X1,Y3,Z3','97AD, 10 YEARS, 5'),(183,'TIJ0BFL5','2018-06-02','2018-06-03','X1,Y3,Z3','97AD, 10 YEARS, 3'),(184,'TIJ0C0L5','2018-08-18','2018-08-13','X1,Y3,Z3','928C, 10 YEARS, 3'),(185,'TIJ0C1L5','2018-12-01','2018-12-01','X1,Y3,Z3','A1EB, 10 YEARS, 1'),(186,'TIJ0C5L5','2018-12-01','2018-12-03','X1,Y3,Z3','A1EB, 10 YEARS, 5'),(187,'TIJ0C7L5','2018-10-06','2018-10-09','X1,Y3,Z3','CBB9, 10 YEARS, 3'),(188,'TIJ001L5','2017-03-05','1970-01-01','X1,Y3,Z3','AD8D, EOM, 3       <===> Fecha Incompleta '),(189,'TIJ002L5','2017-03-04','1970-01-01','X1,Y3,Z3','AD8D, EOM, 1       <===> Fecha Incompleta '),(190,'TIJ00BL5','2017-11-05','1970-01-01','X4,Y2,Z3','AF7B, 10 YEARS, 4       <===> Fecha Incompleta '),(191,'TIJ01CL5','2017-05-07','1970-01-01','X4,Y2,Z3','B6DC, EOM, 3       <===> Fecha Incompleta '),(192,'TIJ01EL5','2017-08-05','2017-08-06','X4,Y2,Z3','BB01, 10 YEARS, 3'),(193,'TIJ020L5','2017-04-01','2017-04-02','X4,Y2,Z3','9F03, 10 YEARS, 2'),(194,'TIJ021L5','2017-10-07','1970-01-01','X4,Y2,Z3','BBA9, 10 YEARS, TIJ_1_INCR, 1       <===> Fecha Incompleta '),(195,'TIJ022L5','2017-11-05','1970-01-01','X4,Y2,Z3','AF7B, 10 YEARS, TIJ_1_FULL, 3       <===> Fecha Incompleta '),(196,'TIJ024L5','2017-04-02','1970-01-01','X4,Y2,Z3','9F03, EOM, 3       <===> Fecha Incompleta '),(197,'TIJ027L5','2017-04-01','1970-01-01','X4,Y2,Z3','9F03, EOM, 1       <===> Fecha Incompleta '),(198,'TIJ02FL5','2017-08-05','2017-08-05','X4,Y2,Z3','BB01, 10 YEAR, 1'),(199,'TIJ030L5','2017-12-02','2017-12-03','X4,Y2,Z3','91ED, 10 YEARS, 2'),(200,'TIJ042L5','2017-09-02','2017-09-03','X3,Y2,Z3','9FAD, 10 YEARS, 2'),(201,'TIJ045L5','2017-09-02','2017-09-02','X3,Y2,Z3','9FAD, 10 YEARS, 1'),(202,'TIJ047L5','2017-11-04','1970-01-01','X3,Y2,Z3','AF7B, 10 YEARS, TIJ_1_FULL, 1       <===> Fecha Incompleta '),(203,'TIJ049L5','2017-05-06','1970-01-01','X3,Y2,Z3','B6DC, EOM, 1       <===> Fecha Incompleta '),(204,'TIJ04DL5','2017-09-02','2017-09-03','X3,Y2,Z3','9FAD, 10 YEARS, 4'),(205,'TIJ04EL5','2017-10-08','1970-01-01','X3,Y2,Z3','BBA9, 10 YEARS, 2       <===> Fecha Incompleta '),(206,'TIJ054L5','2017-12-02','2017-12-02','X3,Y2,Z3','91ED, 10 YEARS, 1'),(207,'TIJ05CL5','2017-05-07','1970-01-01','X3,Y2,Z3','B6DC, EOM, 2       <===> Fecha Incompleta '),(208,'TIJ060L5','2017-12-02','2017-12-03','X3,Y2,Z3','91ED, 10 YEARS, 4'),(209,'TIJ067L5','2017-06-02','1970-01-01','X3,Y2,Z3','A772, EOM, 1       <===> Fecha Incompleta '),(210,'TIJ06AL5','2017-06-04','1970-01-01','X2,Y2,Z3','A772, EOM, 4       <===> Fecha Incompleta '),(211,'TIJ06BL5','2017-06-04','1970-01-01','X2,Y2,Z3','A772, EOM, 2       <===> Fecha Incompleta '),(212,'TIJ06FL5','2017-06-04','1970-01-01','X2,Y2,Z3','A772, EOM, 3       <===> Fecha Incompleta '),(213,'TIJ07BL5','2017-07-02','1970-01-01','X2,Y2,Z3','8A08, EOM June, 2       <===> Fecha Incompleta '),(214,'TIJ08EL5','2017-07-01','2017-07-01','X2,Y2,Z3','8A08, 10 YEARS, 1'),(215,'TIJ095L5','2017-07-02','1970-01-01','X2,Y2,Z3','8A08, EOM June, 3       <===> Fecha Incompleta '),(216,'TIJ0A1L5','2017-08-05','2017-08-06','X2,Y2,Z3','BB01, 10 YEAR, 2'),(217,'TIJ0A3L5','2017-01-07','2017-01-07','X2,Y2,Z3','F22D, 10 YEARS, 1'),(218,'TIJ0A8L5','2017-01-09','1970-01-01','X2,Y2,Z3','F22D, EOM, 2       <===> Fecha Incompleta '),(219,'TIJ0A9L5','2017-01-08','1970-01-01','X2,Y2,Z3','F22D, EOM, 3       <===> Fecha Incompleta '),(220,'TIJ0AAL5','1970-01-01','1970-01-01','X1,Y2,Z3','AF7B, 10 YEARS, TIJ_1_FULL, 2       <===> Fecha Incompleta 43044'),(221,'TIJ0ABL5','2017-12-02','2017-12-03','X1,Y2,Z3','91ED, 10 YEARS, 3'),(222,'TIJ0ACL5','2017-08-05','2017-08-06','X1,Y2,Z3','BB01, 10 YEARS, 4'),(223,'TIJ0B0L5','2017-02-05','1970-01-01','X1,Y2,Z3','DE9F, EOM, 3       <===> Fecha Incompleta '),(224,'TIJ0B8L5','2017-09-02','2017-09-03','X1,Y2,Z3','9FAD, 10 YEARS, 3'),(225,'TIJ0BAL5','2017-02-05','1970-01-01','X1,Y2,Z3','DE9F, EOM, 2       <===> Fecha Incompleta '),(226,'TIJ0BEL5','2017-02-04','1970-01-01','X1,Y2,Z3','DE9F, EOM, 1       <===> Fecha Incompleta '),(227,'TIJ0C2L5','2017-10-08','1970-01-01','X1,Y2,Z3','BBA9, 10 YEARS, TIJ_1_INCR, 4       <===> Fecha Incompleta '),(228,'TIJ0C4L5','2017-03-05','1970-01-01','X1,Y2,Z3','AD8D, EOM, 2       <===> Fecha Incompleta '),(229,'TIJ0C6L5','1970-01-01','1970-01-01','X1,Y2,Z3','BBA9, 10 YEARS, 3       <===> Fecha Incompleta 43016'),(230,'FSU463L5','1970-01-01','1970-01-01','X4,Y1,Z3','EOM, JAN-2016       <===> Fecha Incompleta 42370'),(231,'FSU465L5','2016-03-01','1970-01-01','X4,Y1,Z3','WK2 MAR 16       <===> Fecha Incompleta '),(232,'FSU476L5','2016-02-01','1970-01-01','X4,Y1,Z3','WK4 FEB 16       <===> Fecha Incompleta '),(233,'FSU478L5','2016-04-01','1970-01-01','X4,Y1,Z3','EOM APRIL 16, 3       <===> Fecha Incompleta '),(234,'FSU479L5','2016-03-01','1970-01-01','X4,Y1,Z3','WK1, MAR16       <===> Fecha Incompleta '),(235,'FSU487L5','2016-01-02','1970-01-01','X4,Y1,Z3','B7A5, 10 YEARS, TIJ_1_EOM, 1       <===> Fecha Incompleta '),(236,'FSU497L5','2016-01-01','1970-01-01','X4,Y1,Z3','EOM JAN 2016       <===> Fecha Incompleta '),(237,'FSU499L5','2016-04-01','1970-01-01','X4,Y1,Z3','WK3 APRIL 16       <===> Fecha Incompleta '),(238,'TIJ007L5','2016-04-07','1970-01-01','X4,Y1,Z3','DA3B, 10 YEARS, TIJ_1_EOM, 1       <===> Fecha Incompleta '),(239,'TIJ008L5','1970-01-01','1970-01-01','X4,Y1,Z3','EOM APRIL 16, 2       <===> Fecha Incompleta 42461'),(240,'TIJ010L5','2016-02-01','1970-01-01','X3,Y1,Z3','EOM FEB 16       <===> Fecha Incompleta '),(241,'TIJ011L5','2016-02-01','1970-01-01','X3,Y1,Z3','EOM FEB 16       <===> Fecha Incompleta '),(242,'TIJ012L5','2016-03-01','1970-01-01','X3,Y1,Z3','EOM       <===> Fecha Incompleta '),(243,'TIJ018L5','2016-11-06','1970-01-01','X3,Y1,Z3','C582, EOM, 3       <===> Fecha Incompleta '),(244,'TIJ019L5','2016-11-06','1970-01-01','X3,Y1,Z3','C582, EOM, 2       <===> Fecha Incompleta '),(245,'TIJ02BL5','2016-12-03','1970-01-01','X3,Y1,Z3','C21C, EOM, 1       <===> Fecha Incompleta '),(246,'TIJ032L5','2016-12-03','2016-12-04','X3,Y1,Z3','CZIC, 10 YEAR, 2'),(247,'TIJ035L5','2016-12-04','1970-01-01','X3,Y1,Z3','C21C, EOM, 3       <===> Fecha Incompleta '),(248,'TIJ053L5','2016-08-06','1970-01-01','X3,Y1,Z3','EOM, 1       <===> Fecha Incompleta '),(249,'TIJ055L5','2016-08-06','1970-01-01','X3,Y1,Z3','EOM, 2       <===> Fecha Incompleta '),(250,'TIJ056L5','2016-08-08','1970-01-01','X2,Y1,Z3','EOM, 1       <===> Fecha Incompleta '),(251,'TIJ066L5','2016-09-03','1970-01-01','X2,Y1,Z3','A7BA, EOM, 1       <===> Fecha Incompleta '),(252,'TIJ069L5','2016-09-03','1970-01-01','X2,Y1,Z3','A7BA, EOM, 2       <===> Fecha Incompleta '),(253,'TIJ075L5','2016-10-01','2016-10-01','X2,Y1,Z3','86BE, 10 YEARS, 3'),(254,'TIJ07CL5','2016-10-01','1970-01-01','X2,Y1,Z3','86BE, EOM, 2       <===> Fecha Incompleta '),(255,'TIJ07EL5','2016-10-01','2016-10-01','X2,Y1,Z3','86BE, 10 YEAR, 1'),(256,'TIJ07FL5','2016-11-05','1970-01-01','X2,Y1,Z3','C582, EOM, 1       <===> Fecha Incompleta '),(257,'TIJ08CL5','2016-03-01','1970-01-01','X2,Y1,Z3','EOM, MARCH 16       <===> Fecha Incompleta '),(258,'TIJ08FL5','2016-07-02','1970-01-01','X2,Y1,Z3','EOM.SUNE, 2       <===> Fecha Incompleta '),(259,'TIJ097L5','2016-06-04','1970-01-01','X2,Y1,Z3','EOM , 2       <===> Fecha Incompleta '),(260,'TIJ098L5','2016-04-04','1970-01-01','X1,Y1,Z3','EOM, 1       <===> Fecha Incompleta '),(261,'TIJ09DL5','2016-04-01','1970-01-01','X1,Y1,Z3','EOM APRIL 16       <===> Fecha Incompleta '),(262,'FSU462L5','2015-09-01','1970-01-01','X1,Y1,Z3','EOM, SEP 15       <===> Fecha Incompleta '),(263,'FSU483L5','2015-10-01','1970-01-01','X1,Y1,Z3','OEM, OCTUBRE 2015       <===> Fecha Incompleta '),(264,'FSU489L5','2015-09-01','1970-01-01','X1,Y1,Z3','EOM SEP 15       <===> Fecha Incompleta '),(265,'FSU492L5','2015-07-01','1970-01-01','X1,Y1,Z3','EOM JUL 15       <===> Fecha Incompleta '),(266,'FSU510L5','2015-12-05','1970-01-01','X1,Y1,Z3','9CD9, 10 YEARS,TIJ_1_E0M, 1       <===> Fecha Incompleta '),(267,'FSU512L5','2015-08-01','1970-01-01','X1,Y1,Z3','EOM AUG 15       <===> Fecha Incompleta '),(268,'FSU495L5','2014-07-01','1970-01-01','X1,Y1,Z3','EOM       <===> Fecha Incompleta '),(269,'FSU496L5','2014-08-02','1970-01-01','X1,Y1,Z3','AFC6, 10 YEARS, TIJ_1_EOM, 1       <===> Fecha Incompleta '),(270,'FSU460L5','1970-01-01','1970-01-01','','ETIQUETA CORTADA       <===> Fecha Incompleta '),(271,'FSU488L5','1970-01-01','1970-01-01','','Solo Mes, sin A�o, y REFERENCIAS       <===> Fecha Incompleta '),(272,'TIJ044L5','1970-01-01','1970-01-01','','RAYADA LA ETIQUETA       <===> Fecha Incompleta '),(273,'TIJ077L5','1970-01-01','1970-01-01','','CF31, 10 YEARS, 2       <===> Fecha Incompleta ');
/*!40000 ALTER TABLE `t_Cintas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Depto`
--

DROP TABLE IF EXISTS `t_Depto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Depto` (
  `id_depto` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`id_depto`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Depto`
--

LOCK TABLES `t_Depto` WRITE;
/*!40000 ALTER TABLE `t_Depto` DISABLE KEYS */;
INSERT INTO `t_Depto` VALUES (1,'INFORMATION TECHNOLOGY'),(2,'SHIPPING AND LOGISTICS'),(3,'MATERIALS'),(4,'MANUFACTURING ENGINEERING'),(5,'INVENTORY CONTROL'),(6,'OPERATIONS'),(7,'QUALITY'),(8,'EMPLOYMENT  AND RECRUITING'),(9,'MANUFACTURING SUPPORT'),(10,'Facilities Maintenance'),(11,'Industrial Engineering');
/*!40000 ALTER TABLE `t_Depto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Edo_epo`
--

DROP TABLE IF EXISTS `t_Edo_epo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Edo_epo` (
  `id_edo_epo` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`id_edo_epo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Edo_epo`
--

LOCK TABLES `t_Edo_epo` WRITE;
/*!40000 ALTER TABLE `t_Edo_epo` DISABLE KEYS */;
INSERT INTO `t_Edo_epo` VALUES (1,'OPERABLE'),(2,'NO OPERABLE');
/*!40000 ALTER TABLE `t_Edo_epo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Empleados`
--

DROP TABLE IF EXISTS `t_Empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Empleados` (
  `id_empleado` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_ubicacion` smallint(5) unsigned NOT NULL,
  `id_puesto` smallint(5) unsigned NOT NULL,
  `id_supervisor` smallint(5) unsigned NOT NULL,
  `id_depto` smallint(5) unsigned NOT NULL,
  `id_centro_costos` smallint(5) unsigned NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `ntid` varchar(20) NOT NULL,
  `correo_electronico` varchar(50) NOT NULL,
  `rol` varchar(25) DEFAULT NULL,
  `foto` varchar(100) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_empleado`),
  KEY `id_ubicacion` (`id_ubicacion`),
  KEY `id_puesto` (`id_puesto`),
  KEY `id_supervisor` (`id_supervisor`),
  KEY `id_depto` (`id_depto`),
  KEY `id_centro_costos` (`id_centro_costos`),
  CONSTRAINT `t_Empleados_ibfk_1` FOREIGN KEY (`id_ubicacion`) REFERENCES `t_Ubicacion` (`id_ubicacion`) ON UPDATE CASCADE,
  CONSTRAINT `t_Empleados_ibfk_2` FOREIGN KEY (`id_puesto`) REFERENCES `t_Puesto` (`id_puesto`) ON UPDATE CASCADE,
  CONSTRAINT `t_Empleados_ibfk_3` FOREIGN KEY (`id_supervisor`) REFERENCES `t_Supervisor` (`id_supervisor`) ON UPDATE CASCADE,
  CONSTRAINT `t_Empleados_ibfk_4` FOREIGN KEY (`id_depto`) REFERENCES `t_Depto` (`id_depto`) ON UPDATE CASCADE,
  CONSTRAINT `t_Empleados_ibfk_5` FOREIGN KEY (`id_centro_costos`) REFERENCES `t_Centro_Costos` (`id_centro_costos`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Empleados`
--

LOCK TABLES `t_Empleados` WRITE;
/*!40000 ALTER TABLE `t_Empleados` DISABLE KEYS */;
INSERT INTO `t_Empleados` VALUES (1,2,1,1,1,1,'DEPTO IT','DEPTO IT','9999999','DEPTOIT@JABIL.COM',NULL,'vistas/img/empleados/default/anonymous.png','2021-05-07 22:09:54'),(2,4,2,2,3,3,'GILBERTO','JIMENEZ RICARDEZ','2370721','GILBERTO_JIMENEZ20721@JABIL.COM',NULL,'vistas/img/empleados/default/anonymous.png','2021-05-08 14:33:46'),(3,4,3,3,4,4,'ALVARO','JURADO FLORES','2508819','ALVARO_JURADO@JABIL.COM',NULL,'vistas/img/empleados/default/anonymous.png','2021-05-08 14:35:15'),(4,4,4,4,2,2,'JUAN','JOFFROY TREVINO','2410825','JUAN_JOFFROY@JABIL.COM',NULL,'vistas/img/empleados/JOFFROY TREVINO/456.png','2021-05-08 14:41:24'),(5,4,5,6,6,6,'DIEGO','OSUNA PAEZ','1172019','DIEGO_OSUNA@JABIL.COM',NULL,'vistas/img/empleados/default/anonymous.png','2021-05-09 16:06:25'),(6,4,7,7,7,7,'MARIA','JACOBO PARRA','2794304','Maria_Jacobo4304@Jabil.com',NULL,'vistas/img/empleados/2794304/822.png','2021-05-12 20:56:01'),(7,6,8,8,4,8,'BIANCA','OCHOA','2805104','BIANCA_OCHOA@JABIL.COM',NULL,'vistas/img/empleados/default/anonymous.png','2021-05-19 18:11:27'),(8,4,9,9,8,9,'ESTEFANY','ROSALES RAMOS','2011116','ESTEFANY_ROSALES@JABIL.COM',NULL,'vistas/img/empleados/default/anonymous.png','2021-05-19 18:20:48'),(9,4,10,10,9,10,'MONICA','GUTIERREZ CONTRERAS','2283169','MONICA_GUTIERREZ1@JABIL.COM',NULL,'vistas/img/empleados/GUTIERREZ CONTRERAS/796.png','2021-05-22 15:22:14'),(10,6,11,2,4,3,'Adan','Felix','2876241','adan_felix@jabil.com',NULL,'vistas/img/empleados/Felix/879.png','2021-05-24 17:52:44'),(13,5,8,6,8,4,'nombre varios','apellidos varios','2345','correo@dfg.com',NULL,'vistas/img/empleados/2345/220.png','2021-05-29 12:29:23'),(14,4,13,11,11,11,'Edgar','Avila Garrido','3073662','edgar_avila3662@jabil.com',NULL,'vistas/img/empleados/3073662/706.png','2021-06-15 19:07:32');
/*!40000 ALTER TABLE `t_Empleados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Linea`
--

DROP TABLE IF EXISTS `t_Linea`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Linea` (
  `id_linea` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_linea`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Linea`
--

LOCK TABLES `t_Linea` WRITE;
/*!40000 ALTER TABLE `t_Linea` DISABLE KEYS */;
INSERT INTO `t_Linea` VALUES (1,'NOAPLICA'),(3,'PRODUCCION'),(5,'FRU'),(6,'ACE'),(7,'ACE2'),(8,'LIGAMAX'),(9,'ERCA'),(10,'MINIMONARCA'),(11,'XCEL'),(12,'BUCANEER'),(13,'FOCUS'),(14,'BRICK');
/*!40000 ALTER TABLE `t_Linea` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Marca`
--

DROP TABLE IF EXISTS `t_Marca`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Marca` (
  `id_marca` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Marca`
--

LOCK TABLES `t_Marca` WRITE;
/*!40000 ALTER TABLE `t_Marca` DISABLE KEYS */;
INSERT INTO `t_Marca` VALUES (2,'HP'),(3,'LOGITECH'),(4,'CMTECK'),(5,'ZEBRA'),(6,'IPHONE'),(7,'SANSUMG'),(8,'LANIX'),(9,'VIEWSONY'),(10,'NO APLICA');
/*!40000 ALTER TABLE `t_Marca` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Modelo`
--

DROP TABLE IF EXISTS `t_Modelo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Modelo` (
  `id_modelo` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_modelo`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Modelo`
--

LOCK TABLES `t_Modelo` WRITE;
/*!40000 ALTER TABLE `t_Modelo` DISABLE KEYS */;
INSERT INTO `t_Modelo` VALUES (1,'NO APLICA'),(2,'H390'),(3,'2013 SLIM DOCKING'),(4,'TPN-DA17'),(5,'SUPER SLIM 2012'),(6,'FSP025-OYAA3'),(7,'ZM330'),(8,'XR'),(9,'GALAXY A31'),(10,'ELITEBOOK 840 G6'),(11,'TPN-CA16'),(12,'ZD620'),(13,'GX430T'),(14,'ZT510'),(15,'ZT610'),(16,'ZT620'),(17,'ELITEBOOK 840 G5'),(18,'PPP09C'),(19,'X550 COLOR AZUL'),(20,'PG706HD'),(21,'EliteBook 840 G3'),(22,'HSTNN-LAA40'),(23,'MC 930'),(24,'CRD-MC-93-2SUCHG'),(25,'ZQ 320'),(26,'GALAXY A01'),(27,'NO APLICA'),(28,'SM-A115M'),(29,'EP-TA20D');
/*!40000 ALTER TABLE `t_Modelo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Periferico`
--

DROP TABLE IF EXISTS `t_Periferico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Periferico` (
  `id_periferico` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_periferico`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Periferico`
--

LOCK TABLES `t_Periferico` WRITE;
/*!40000 ALTER TABLE `t_Periferico` DISABLE KEYS */;
INSERT INTO `t_Periferico` VALUES (1,'DESKTOP','2021-05-07 22:12:51'),(2,'LAPTOP','2021-05-07 22:13:00'),(3,'MONITOR','2021-05-07 22:13:13'),(4,'HEADSET','2021-05-08 12:01:54'),(5,'DOCKING STATION','2021-05-08 12:02:39'),(6,'CARGADOR LAPTOP','2021-05-08 12:03:07'),(7,'CARGADOR CELULAR','2021-05-08 12:03:21'),(8,'CARGADOR RF','2021-05-08 12:03:37'),(9,'BOCINAS','2021-05-08 12:04:55'),(10,'CARGADOR DOCKING','2021-05-08 13:01:00'),(11,'SMARTPHONE','2021-05-09 16:10:50'),(12,'CARGADOR IPHONE','2021-05-09 16:16:21'),(14,'IMPRESORA TERMICA','2021-05-14 18:40:16'),(15,'PROJECTOR','2021-05-22 15:30:26'),(16,'IMPRESORA PORTABLE','2021-06-02 13:05:46'),(17,'RF GUN','2021-06-02 13:07:21');
/*!40000 ALTER TABLE `t_Periferico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_PlanTelefonia`
--

DROP TABLE IF EXISTS `t_PlanTelefonia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_PlanTelefonia` (
  `id_plan_tel` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id_plan_tel`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_PlanTelefonia`
--

LOCK TABLES `t_PlanTelefonia` WRITE;
/*!40000 ALTER TABLE `t_PlanTelefonia` DISABLE KEYS */;
INSERT INTO `t_PlanTelefonia` VALUES (1,'NO APLICA'),(2,'TMSLE MIX 1500 24M'),(3,'TMSLE 6500D VTR 24M'),(4,'TMSLE D 1500 VC 24M');
/*!40000 ALTER TABLE `t_PlanTelefonia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Productos`
--

DROP TABLE IF EXISTS `t_Productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Productos` (
  `id_producto` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_almacen` smallint(5) unsigned NOT NULL,
  `id_edo_epo` smallint(5) unsigned NOT NULL,
  `id_marca` smallint(5) unsigned NOT NULL,
  `id_modelo` smallint(5) unsigned NOT NULL,
  `id_linea` smallint(5) unsigned NOT NULL,
  `id_ubicacion` smallint(5) unsigned NOT NULL,
  `id_periferico` smallint(5) unsigned NOT NULL,
  `id_empleado` smallint(5) unsigned DEFAULT 1,
  `id_telefonia` smallint(5) unsigned NOT NULL,
  `id_plan_tel` smallint(5) unsigned NOT NULL,
  `num_tel` varchar(25) DEFAULT NULL,
  `cuenta` varchar(45) DEFAULT NULL,
  `direcc_mac_tel` varchar(20) DEFAULT NULL,
  `imei_tel` varchar(30) DEFAULT NULL,
  `nomenclatura` varchar(45) DEFAULT NULL,
  `num_serie` varchar(45) DEFAULT NULL,
  `imagen_producto` varchar(100) NOT NULL,
  `stock` smallint(5) unsigned DEFAULT 0,
  `precio_compra` decimal(10,2) DEFAULT NULL,
  `precio_venta` decimal(10,2) DEFAULT NULL,
  `cuantas_veces` tinyint(4) DEFAULT NULL,
  `asignado` char(1) DEFAULT 'N',
  `fecha_arribo` datetime NOT NULL DEFAULT current_timestamp(),
  `edo_tel` varchar(15) DEFAULT NULL,
  `num_ip` varchar(20) DEFAULT NULL,
  `comentarios` text DEFAULT NULL,
  `asset` varchar(15) DEFAULT NULL,
  `loftware` varchar(10) DEFAULT NULL,
  `estacion` varchar(50) DEFAULT NULL,
  `npa` varchar(15) DEFAULT NULL,
  `idf` varchar(5) DEFAULT NULL,
  `patch_panel` varchar(5) DEFAULT NULL,
  `puerto` varchar(5) DEFAULT NULL,
  `funcion` varchar(20) DEFAULT NULL,
  `jls` varchar(15) DEFAULT NULL,
  `qdc` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `id_almacen` (`id_almacen`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_edo_epo` (`id_edo_epo`),
  KEY `id_marca` (`id_marca`),
  KEY `id_modelo` (`id_modelo`),
  KEY `id_linea` (`id_linea`),
  KEY `id_ubicacion` (`id_ubicacion`),
  KEY `id_periferico` (`id_periferico`),
  KEY `id_telefonia` (`id_telefonia`),
  KEY `id_plan_tel` (`id_plan_tel`),
  CONSTRAINT `t_Productos_ibfk_1` FOREIGN KEY (`id_almacen`) REFERENCES `t_Almacen` (`id_almacen`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_10` FOREIGN KEY (`id_plan_tel`) REFERENCES `t_PlanTelefonia` (`id_plan_tel`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_2` FOREIGN KEY (`id_empleado`) REFERENCES `t_Empleados` (`id_empleado`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_3` FOREIGN KEY (`id_edo_epo`) REFERENCES `t_Edo_epo` (`id_edo_epo`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_4` FOREIGN KEY (`id_marca`) REFERENCES `t_Marca` (`id_marca`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_5` FOREIGN KEY (`id_modelo`) REFERENCES `t_Modelo` (`id_modelo`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_6` FOREIGN KEY (`id_linea`) REFERENCES `t_Linea` (`id_linea`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_7` FOREIGN KEY (`id_ubicacion`) REFERENCES `t_Ubicacion` (`id_ubicacion`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_8` FOREIGN KEY (`id_periferico`) REFERENCES `t_Periferico` (`id_periferico`) ON UPDATE CASCADE,
  CONSTRAINT `t_Productos_ibfk_9` FOREIGN KEY (`id_telefonia`) REFERENCES `t_Telefonia` (`id_telefonia`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Productos`
--

LOCK TABLES `t_Productos` WRITE;
/*!40000 ALTER TABLE `t_Productos` DISABLE KEYS */;
INSERT INTO `t_Productos` VALUES (1,1,1,3,2,1,1,4,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,'vistas/img/productos/default/anonymous.png',1,60.00,60.00,NULL,'N','2021-05-08 19:46:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,1,1,2,4,1,1,10,3,1,1,'0','','','','MXTIJH067HGSL','WHQR0AARD281K','vistas/img/productos/default/anonymous.png',0,60.00,60.00,1,'N','2021-05-08 13:04:29','NO Aplica','','','','','','','','','','','',''),(3,1,1,2,3,1,1,5,3,1,1,'0','','','','MXTIJH067HGSL','5CG001WDVH','vistas/img/productos/default/anonymous.png',0,220.00,220.00,1,'N','2021-05-08 13:06:18','NO Aplica','','','','','','','','','','','',''),(4,1,1,2,5,1,1,5,4,1,1,'0','','','','','5CG933XV2T','vistas/img/productos/default/anonymous.png',0,220.00,220.00,1,'N','2021-05-08 14:44:20','NO Aplica','','','','','','','','','','','',''),(5,1,1,2,4,1,1,10,4,1,1,'0','','','','','WHQRN0A1RCKM8C','vistas/img/productos/default/anonymous.png',0,80.00,80.00,1,'N','2021-05-08 14:46:22','NO Aplica','','','','','','','','','','','',''),(6,1,1,4,7,1,1,9,2,1,1,'0','','','','','B07K46LDZM','vistas/img/productos/default/anonymous.png',0,80.00,80.00,1,'N','2021-05-08 15:01:42','NO Aplica','','','','','','','','','','','',''),(7,1,1,5,6,1,1,8,2,1,1,'0','','','','JHB3-ZQPRN-02','H00015820','vistas/img/productos/default/anonymous.png',0,60.00,60.00,1,'N','2021-05-08 15:10:12','NO Aplica','','','','161','','','','','','','',''),(8,1,1,5,6,1,1,8,2,1,1,'0','','','','JHB3-ZQPRN-01','H00003749','vistas/img/productos/default/anonymous.png',0,60.00,60.00,1,'N','2021-05-08 15:13:12','NO Aplica','','','','160','BLOWERASSY','','','','','','',''),(9,1,1,6,8,1,1,11,5,2,1,'0','','','','','352883110190543','vistas/img/productos/default/anonymous.png',0,800.00,800.00,1,'N','2021-05-09 16:13:49','Asignado','','','','','','','','','','','',''),(10,1,1,6,1,1,1,7,5,1,1,'0','','','','','','vistas/img/productos/default/anonymous.png',0,60.00,60.00,1,'N','2021-05-09 16:18:35','NO Aplica','','','','','','','','','','','',''),(11,1,1,7,9,1,1,11,1,1,1,'0','','','','','RF8N81C55GT','vistas/img/productos/default/anonymous.png',1,320.00,320.00,NULL,'N','2021-05-12 20:43:19','Disponible','','Solo telefono, sin chip','','','','','','','','','',''),(12,1,1,7,9,1,1,11,1,1,1,'0','','','','','RF8N1C57EM','vistas/img/productos/default/anonymous.png',1,320.00,320.00,NULL,'N','2021-05-12 20:44:57','Disponible','','','','','','','','','','','',''),(13,1,1,7,9,1,1,11,1,1,1,'0','','','','','RF8N81C529B','vistas/img/productos/default/anonymous.png',1,320.00,320.00,NULL,'N','2021-05-12 20:46:53','Disponible','','Sin chip solo teléfono','','','','','','','','','',''),(14,1,1,5,12,3,5,14,1,1,1,'0','','','','','D1J181206570','vistas/img/productos/default/anonymous.png',1,800.00,800.00,NULL,'N','2021-05-14 18:46:31','NO Aplica','10.53.221.27','','MXTIJH3000102','152','BLOWER ASSY','10522','IDF2','PP10','40','MES','',''),(15,1,1,5,13,5,5,14,1,1,1,'0','','','','','32J194701397','vistas/img/productos/default/anonymous.png',1,800.00,800.00,NULL,'N','2021-05-14 18:52:03','NO Aplica','10.53.221.40','','MXTIJH3000144','198','FRU32','','IDF2','PP11','32','','',''),(16,1,1,5,14,7,6,14,1,1,1,'0','','','','','34J1940000335','vistas/img/productos/default/anonymous.png',1,1000.00,1000.00,NULL,'N','2021-05-14 19:03:15','NO Aplica','10.53.221.18','','MXTIJH3000015','','CME SMART STATION','AUC-000005','IDF2','PP01','29','','',''),(17,1,1,5,16,8,6,14,1,1,1,'0','','','','nomenclaturauno','76J190200525','vistas/img/productos/default/anonymous.png',1,100.00,100.00,NULL,'N','2021-05-14 19:09:22','NO Aplica','10.53.218.249','','MXTIJH3000021','','','','IDF1','PP02','39','','',''),(18,1,1,2,17,1,1,2,7,1,1,'0','','','','MXTIJH251BL3L','5CG0451BL3','vistas/img/productos/default/anonymous.png',0,1200.00,1200.00,1,'N','2021-05-19 18:07:23','NO Aplica','','','','','','','','','','','',''),(19,1,1,2,11,1,1,6,7,1,1,'0','','','','MXTIJH251BL3L','WHGRH0BGCE62KP','vistas/img/productos/default/anonymous.png',0,60.00,60.00,1,'N','2021-05-19 18:08:50','NO Aplica','','','','','','','','','','','',''),(20,1,1,2,17,1,1,2,8,1,1,'0','','','','','5CG90497GS','vistas/img/productos/default/anonymous.png',0,1200.00,1200.00,1,'N','2021-05-19 18:22:12','NO Aplica','','','','','','','','','','','',''),(21,1,1,2,18,1,1,6,8,1,1,'0','','','','','WFTKV0EGCBOREG0E','vistas/img/productos/default/anonymous.png',0,60.00,60.00,1,'N','2021-05-19 18:24:44','NO Aplica','','','','','','','','','','','',''),(25,1,1,8,19,1,1,11,1,1,1,'0','','','','','351480450435275','vistas/img/productos/default/anonymous.png',1,97.00,97.00,NULL,'N','2021-05-22 15:04:08','Disponible','','Solo se registra el telefono sin el Chip','','','','','','','','','',''),(26,1,1,9,20,1,1,15,9,1,1,'0','','','','','V5519020117','vistas/img/productos/varios/721.jpg',1,800.00,800.00,0,'N','2021-05-22 15:33:13','NO Aplica','','','','','','','','','','','',''),(27,1,1,2,21,1,1,2,10,1,1,'0','','','','','5CG8242V6N','vistas/img/productos/varios/507.jpg',0,1200.00,1200.00,1,'N','2021-05-24 17:57:33','NO Aplica','','','MXTIJH3000292','','','','','','','','',''),(28,1,1,2,22,1,1,6,10,1,1,'0','','','','MXTIJH3000292','WDUUV0B5R42303','vistas/img/productos/default/anonymous.png',0,60.00,60.00,1,'N','2021-05-24 18:02:15','','','','','','','','','','','','',''),(29,1,1,5,23,1,1,17,2,1,1,'0','','','','JHB3-ZDMCS-09','19344522501987','vistas/img/productos/varios/347.jpg',0,1200.00,1200.00,1,'N','2021-06-02 13:12:01','NO Aplica','','','','','','','','','','','',''),(30,1,1,5,24,1,1,8,2,1,1,'0','','','','JHB3-ZDMCS-09','20035523801304','vistas/img/productos/varios/640.jpg',0,60.00,60.00,1,'N','2021-06-02 13:16:49','NO Aplica','','','','','','','','','','','',''),(31,1,1,5,23,1,1,17,2,1,1,'0','','','','JHB3-ZDMCS-10','19344522501950','vistas/img/productos/varios/948.jpg',0,1200.00,1200.00,1,'N','2021-06-02 13:20:41','NO Aplica','','','','','','','','','','','',''),(32,1,1,5,24,1,1,8,2,1,1,'0','','','','JHB3-ZDMCS-10','20035523801310','vistas/img/productos/varios/682.jpg',0,60.00,60.00,1,'N','2021-06-02 13:22:34','NO Aplica','','','','','','','','','','','',''),(33,1,1,5,25,1,1,16,2,1,1,'0','','','','JHB3-ZQPRN-01-160','XXZFJ183902071','vistas/img/productos/varios/600.jpg',0,300.00,300.00,1,'N','2021-06-02 13:26:13','NO Aplica','','','','','','','','','','','',''),(34,1,1,4,25,1,1,16,2,1,1,'0','','','','JHB3-ZQPRN-02-161','XXZFJ18902089','vistas/img/productos/varios/550.jpg',0,300.00,300.00,1,'N','2021-06-02 13:27:57','NO Aplica','','','','','','','','','','','',''),(35,1,1,2,10,1,1,2,6,1,1,'0','','','','MXTIJH25268GL','5CG025268G','vistas/img/productos/varios/592.jpg',0,900.00,900.00,1,'N','2021-06-02 13:48:04','NO Aplica','','','','','','','','','','','',''),(36,1,1,2,10,1,1,6,6,1,1,'0','','','','MXTIJH25268GL','WHGRH0AGCDR7QF','vistas/img/productos/varios/208.jpg',0,60.00,60.00,1,'N','2021-06-02 13:52:13','NO Aplica','','','','','','','','','','','',''),(37,1,1,7,26,1,1,11,1,1,1,'0','','','355620112298167','','','vistas/img/productos/varios/524.png',1,175.00,175.00,NULL,'N','2021-06-03 13:08:21','NO Aplica','','','','','','','','','','','',''),(38,1,1,7,28,1,1,11,14,1,1,'6644097441','','9C:A5:13:45:73:DB','354076117965287','','R9JN80AP53J','vistas/img/productos/default/anonymous.png',0,250.00,250.00,1,'N','2021-06-15 15:41:32','NO Aplica','','','','','','','','','','','',''),(39,1,1,7,29,1,1,7,14,1,1,'0','','','','','R37N7Y31NQ3HM3','vistas/img/productos/default/anonymous.png',0,60.00,60.00,1,'N','2021-06-15 15:43:17','NO Aplica','','','','','','','','','','','','');
/*!40000 ALTER TABLE `t_Productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Puesto`
--

DROP TABLE IF EXISTS `t_Puesto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Puesto` (
  `id_puesto` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_puesto`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Puesto`
--

LOCK TABLES `t_Puesto` WRITE;
/*!40000 ALTER TABLE `t_Puesto` DISABLE KEYS */;
INSERT INTO `t_Puesto` VALUES (1,'SUPERVISOR'),(2,' SR ENTERPRISE RESOURCE P'),(3,'ING DE COMPONENTES SR'),(4,'GTE LOGISTICA Y ADUANAS'),(5,'GERENTE DE PROYECTOS'),(6,'MANUFACTURING ENGINEERING SUPPORT'),(7,'QUALITY SYSTEM AND REGULATORY ENGINEER SR'),(8,'TALENT BENCH QUALITY'),(9,'RECRUITMENT SUPPORT'),(10,'TRAINING II'),(11,'TALENT BENCH MATERIALS'),(12,'Engineer SME'),(13,'Industrial Engineer SME');
/*!40000 ALTER TABLE `t_Puesto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Responsivas`
--

DROP TABLE IF EXISTS `t_Responsivas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Responsivas` (
  `id_responsiva` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` smallint(5) unsigned NOT NULL,
  `id_usuario` smallint(5) unsigned NOT NULL,
  `id_almacen` smallint(5) unsigned NOT NULL,
  `activa` char(1) NOT NULL DEFAULT 'S',
  `num_folio` smallint(5) unsigned NOT NULL,
  `modalidad_entrega` varchar(25) NOT NULL,
  `num_ticket` varchar(30) DEFAULT NULL,
  `responsiva_firmada` varchar(100) DEFAULT NULL,
  `comentario` text DEFAULT NULL,
  `comentario_devolucion` text DEFAULT NULL,
  `productos` text DEFAULT NULL,
  `impuesto` decimal(10,2) DEFAULT NULL,
  `neto` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `fecha_devolucion` date DEFAULT NULL,
  `fecha_asignado` date DEFAULT NULL,
  PRIMARY KEY (`id_responsiva`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_usuario` (`id_usuario`),
  KEY `id_almacen` (`id_almacen`),
  CONSTRAINT `t_Responsivas_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `t_Empleados` (`id_empleado`) ON UPDATE CASCADE,
  CONSTRAINT `t_Responsivas_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `t_Usuarios` (`id_usuario`) ON UPDATE CASCADE,
  CONSTRAINT `t_Responsivas_ibfk_3` FOREIGN KEY (`id_almacen`) REFERENCES `t_Almacen` (`id_almacen`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Responsivas`
--

LOCK TABLES `t_Responsivas` WRITE;
/*!40000 ALTER TABLE `t_Responsivas` DISABLE KEYS */;
INSERT INTO `t_Responsivas` VALUES (1,4,2,1,'S',1,'Permanente','',NULL,'Comentarios',NULL,'[{\"id\":\"4\",\"descripcion\":\"DOCKING STATION\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"220.00\",\"total\":\"220\"},{\"id\":\"5\",\"descripcion\":\"CARGADOR DOCKING\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"80.00\",\"total\":\"80.00\"}]',0.00,300.00,300.00,NULL,'2021-05-08'),(2,2,2,1,'S',2,'Permanente','',NULL,'Comentarios',NULL,'[{\"id\":\"6\",\"descripcion\":\"BOCINAS\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"80.00\",\"total\":\"80.00\"}]',0.00,80.00,80.00,NULL,'2020-08-01'),(3,3,2,1,'N',3,'Permanente','',NULL,'Comentarios',NULL,'[{\"id\":\"3\",\"descripcion\":\"DOCKING STATION\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"220.00\",\"total\":\"220\"},{\"id\":\"2\",\"descripcion\":\"CARGADOR DOCKING\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,280.00,280.00,NULL,'2020-06-08'),(4,2,2,1,'S',4,'Permanente','',NULL,'Comentarios',NULL,'[{\"id\":\"7\",\"descripcion\":\"CARGADOR RF\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60\"},{\"id\":\"8\",\"descripcion\":\"CARGADOR RF\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,120.00,120.00,NULL,'2020-09-07'),(5,2,2,1,'N',5,'Permanente','',NULL,'Comentarios',NULL,'[{\"id\":\"3\",\"descripcion\":\"DOCKING STATION\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"220.00\",\"total\":\"220\"},{\"id\":\"2\",\"descripcion\":\"CARGADOR DOCKING\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,280.00,280.00,NULL,'2021-05-03'),(6,3,2,1,'S',6,'Permanente','',NULL,'Comentarios',NULL,'[{\"id\":\"3\",\"descripcion\":\"DOCKING STATION\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"220.00\",\"total\":\"220\"},{\"id\":\"2\",\"descripcion\":\"CARGADOR DOCKING\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,280.00,280.00,NULL,'2021-05-09'),(7,5,2,1,'S',7,'Permanente','',NULL,'Comentarios',NULL,'[{\"id\":\"9\",\"descripcion\":\"SMARTPHONE\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"800.00\",\"total\":\"800\"},{\"id\":\"10\",\"descripcion\":\"CARGADOR CELULAR\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,860.00,860.00,NULL,'2021-03-08'),(8,7,2,1,'S',8,'Prestamo','',NULL,'Comentarios',NULL,'[{\"id\":\"18\",\"descripcion\":\"LAPTOP\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1200.00\",\"total\":\"1200\"},{\"id\":\"19\",\"descripcion\":\"CARGADOR LAPTOP\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,1260.00,1260.00,'2021-06-11','2021-05-17'),(9,8,2,1,'S',9,'Prestamo','',NULL,'Comentarios',NULL,'[{\"id\":\"20\",\"descripcion\":\"LAPTOP\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1200.00\",\"total\":\"1200\"},{\"id\":\"21\",\"descripcion\":\"CARGADOR LAPTOP\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,1260.00,1260.00,'2021-09-30','2021-04-12'),(10,9,2,1,'N',10,'Prestamo','',NULL,'Comentarios',NULL,'[{\"id\":\"26\",\"descripcion\":\"PROJECTOR\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"800.00\",\"total\":\"800.00\"}]',0.00,800.00,800.00,'2021-02-17','2021-02-03'),(11,10,2,1,'S',11,'Prestamo','',NULL,'Prestamo Indefinido',NULL,'[{\"id\":\"27\",\"descripcion\":\"LAPTOP\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1200.00\",\"total\":\"1200\"},{\"id\":\"28\",\"descripcion\":\"CARGADOR LAPTOP\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,1260.00,1260.00,'2022-12-31','2021-05-13'),(12,2,2,1,'S',12,'Permanente','',NULL,'Comentarios',NULL,'[{\"id\":\"29\",\"descripcion\":\"RF GUN\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1200.00\",\"total\":\"1200\"},{\"id\":\"30\",\"descripcion\":\"CARGADOR RF\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60\"},{\"id\":\"31\",\"descripcion\":\"RF GUN\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"1200.00\",\"total\":\"1200\"},{\"id\":\"32\",\"descripcion\":\"CARGADOR RF\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60\"},{\"id\":\"33\",\"descripcion\":\"IMPRESORA PORTABLE\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300\"},{\"id\":\"34\",\"descripcion\":\"IMPRESORA PORTABLE\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"300.00\",\"total\":\"300.00\"}]',0.00,3120.00,3120.00,NULL,'2020-06-05'),(13,6,2,1,'S',13,'Permanente','',NULL,'Comentarios',NULL,'[{\"id\":\"35\",\"descripcion\":\"LAPTOP\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"900.00\",\"total\":\"900\"},{\"id\":\"36\",\"descripcion\":\"CARGADOR LAPTOP\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,960.00,960.00,NULL,'2020-08-11'),(14,14,2,1,'S',14,'Permanente','',NULL,'IMEI : 354076117965287\r\nWIFI ADDRESS : 9C:A5:13:45:73:DB',NULL,'[{\"id\":\"38\",\"descripcion\":\"SMARTPHONE\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"250.00\",\"total\":\"250\"},{\"id\":\"39\",\"descripcion\":\"CARGADOR CELULAR\",\"cantidad\":\"1\",\"stock\":\"0\",\"precio\":\"60.00\",\"total\":\"60.00\"}]',0.00,310.00,310.00,NULL,'2021-06-15');
/*!40000 ALTER TABLE `t_Responsivas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Supervisor`
--

DROP TABLE IF EXISTS `t_Supervisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Supervisor` (
  `id_supervisor` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`id_supervisor`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Supervisor`
--

LOCK TABLES `t_Supervisor` WRITE;
/*!40000 ALTER TABLE `t_Supervisor` DISABLE KEYS */;
INSERT INTO `t_Supervisor` VALUES (1,'JHON'),(2,'EDGAR GONZALEZ'),(3,'JOSE SIMENTAL QUINTERO'),(4,'NORMA CAZESSUS'),(5,'GUSTAVO LEE'),(6,'LUIS ARMENTA CORONA'),(7,'MAYRA LOPEZ ARMENTA'),(8,'JOSE MARTINEZ'),(9,'RAUL MEDINA RAZO'),(10,'LOURDES GARCIA MANZANARES'),(11,'Carlos Alvarado Magaña');
/*!40000 ALTER TABLE `t_Supervisor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Tareas`
--

DROP TABLE IF EXISTS `t_Tareas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Tareas` (
  `id_tarea` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_empleado` smallint(5) unsigned NOT NULL,
  `id_almacen` smallint(5) unsigned NOT NULL,
  `id_usuario` smallint(5) unsigned NOT NULL,
  `tarea_asignada` varchar(70) NOT NULL,
  `ticket` varchar(30) DEFAULT NULL,
  `comentario1` text DEFAULT NULL,
  `comentario2` text DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  PRIMARY KEY (`id_tarea`),
  KEY `id_empleado` (`id_empleado`),
  KEY `id_almacen` (`id_almacen`),
  KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `t_Tareas_ibfk_1` FOREIGN KEY (`id_empleado`) REFERENCES `t_Empleados` (`id_empleado`) ON UPDATE CASCADE,
  CONSTRAINT `t_Tareas_ibfk_2` FOREIGN KEY (`id_almacen`) REFERENCES `t_Almacen` (`id_almacen`) ON UPDATE CASCADE,
  CONSTRAINT `t_Tareas_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `t_Usuarios` (`id_usuario`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Tareas`
--

LOCK TABLES `t_Tareas` WRITE;
/*!40000 ALTER TABLE `t_Tareas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_Tareas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Telefonia`
--

DROP TABLE IF EXISTS `t_Telefonia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Telefonia` (
  `id_telefonia` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id_telefonia`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Telefonia`
--

LOCK TABLES `t_Telefonia` WRITE;
/*!40000 ALTER TABLE `t_Telefonia` DISABLE KEYS */;
INSERT INTO `t_Telefonia` VALUES (1,'NO APLICA'),(2,'TELCEL');
/*!40000 ALTER TABLE `t_Telefonia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Ubicacion`
--

DROP TABLE IF EXISTS `t_Ubicacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Ubicacion` (
  `id_ubicacion` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY (`id_ubicacion`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Ubicacion`
--

LOCK TABLES `t_Ubicacion` WRITE;
/*!40000 ALTER TABLE `t_Ubicacion` DISABLE KEYS */;
INSERT INTO `t_Ubicacion` VALUES (1,'No Aplica'),(2,'Depto IT'),(3,'ALMACEN'),(4,'MEZZANINE'),(5,'PHILIPS'),(6,'CLEANROOM'),(7,'KITTING');
/*!40000 ALTER TABLE `t_Ubicacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Usuarios`
--

DROP TABLE IF EXISTS `t_Usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Usuarios` (
  `id_usuario` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `usuario` varchar(45) NOT NULL,
  `clave` varchar(80) NOT NULL,
  `perfil` varchar(45) NOT NULL,
  `vendedor` varchar(45) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `estado` tinyint(3) unsigned DEFAULT 0,
  `ultimo_login` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Usuarios`
--

LOCK TABLES `t_Usuarios` WRITE;
/*!40000 ALTER TABLE `t_Usuarios` DISABLE KEYS */;
INSERT INTO `t_Usuarios` VALUES (1,'Administrador','admin','Resp2020Ene','Administrador','','',1,'2021-06-03 23:21:28','2021-05-08 03:50:27'),(2,'RAMON ORTEGA M','Ramon','$2a$07$asxx54ahjppf45sd87a5au33x/JwPbF0YX/cUMxKVc.kIo3kXtIyq','Administrador',NULL,'vistas/img/usuarios/Ramon/435.png',1,'2021-06-15 19:00:32','2021-05-07 20:52:06'),(3,'JACOBO VALENZUELA CASANOVA','Jacobo','$2a$07$asxx54ahjppf45sd87a5aukHS/zw2jaB05TrIEcjrOndoxEgZbvkO','Administrador',NULL,'vistas/img/usuarios/Jacobo/833.png',1,'2021-05-12 14:32:12','2021-05-11 09:27:05'),(4,'LUIS CRUZ MORALES','Luis','$2a$07$asxx54ahjppf45sd87a5auSz3NlSo68oDv6oeWZ473b1BpWF1DjUm','Administrador',NULL,'vistas/img/usuarios/Luis/427.png',1,'2021-05-11 09:27:45','2021-05-11 09:27:45');
/*!40000 ALTER TABLE `t_Usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-16  4:30:01
