-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: bd_responsivas
-- ------------------------------------------------------
-- Server version	10.3.27-MariaDB-0+deb10u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `t_Almacen`
--

DROP TABLE IF EXISTS `t_Almacen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Almacen` (
  `id_almacen` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  PRIMARY KEY (`id_almacen`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Almacen`
--

LOCK TABLES `t_Almacen` WRITE;
/*!40000 ALTER TABLE `t_Almacen` DISABLE KEYS */;
INSERT INTO `t_Almacen` VALUES (1,'PLANTA 3 - ALMACEN');
/*!40000 ALTER TABLE `t_Almacen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Centro_Costos`
--

DROP TABLE IF EXISTS `t_Centro_Costos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Centro_Costos` (
  `id_centro_costos` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `num_centro_costos` varchar(30) NOT NULL,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`id_centro_costos`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Centro_Costos`
--

LOCK TABLES `t_Centro_Costos` WRITE;
/*!40000 ALTER TABLE `t_Centro_Costos` DISABLE KEYS */;
INSERT INTO `t_Centro_Costos` VALUES (1,'17300426','IT'),(2,'17311216','ADUANAS'),(3,'17311217','WAREHOUSE INVENTORY CONTROL'),(4,'17313232','MANUFACTURING'),(5,'17311232','OPERATIONS'),(6,'17313240','PROGRAM MANAGEMENT'),(7,'17313248','QA REGULATORY');
/*!40000 ALTER TABLE `t_Centro_Costos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Cintas`
--

DROP TABLE IF EXISTS `t_Cintas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Cintas` (
  `id_cintas` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `num_serial` varchar(15) NOT NULL,
  `fecha_inic` date DEFAULT NULL,
  `fecha_final` date DEFAULT NULL,
  `ubicacion` varchar(20) NOT NULL,
  `comentarios` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id_cintas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Cintas`
--

LOCK TABLES `t_Cintas` WRITE;
/*!40000 ALTER TABLE `t_Cintas` DISABLE KEYS */;
/*!40000 ALTER TABLE `t_Cintas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Depto`
--

DROP TABLE IF EXISTS `t_Depto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Depto` (
  `id_depto` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`id_depto`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Depto`
--

LOCK TABLES `t_Depto` WRITE;
/*!40000 ALTER TABLE `t_Depto` DISABLE KEYS */;
INSERT INTO `t_Depto` VALUES (1,'INFORMATION TECHNOLOGY'),(2,'SHIPPING AND LOGISTICS'),(3,'MATERIALS'),(4,'MANUFACTURING ENGINEERING'),(5,'INVENTORY CONTROL'),(6,'OPERATIONS'),(7,'QUALITY');
/*!40000 ALTER TABLE `t_Depto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_Edo_epo`
--

DROP TABLE IF EXISTS `t_Edo_epo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_Edo_epo` (
  `id_edo_epo` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(80) NOT NULL,
  PRIMARY KEY (`id_edo_epo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_Edo_epo`
--

LOCK TABLES `t_Edo_epo` WRITE;
/*!40000 ALTER TABLE `t_Edo_epo` DISABLE KEYS */;
INSERT INTO `t_Edo_epo` VALUES (1,'OPERABLE'),(2,'NO OPERABLE');
